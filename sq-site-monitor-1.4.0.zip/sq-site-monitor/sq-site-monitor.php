<?php
/**
 * Plugin Name:       SQ Site Monitor
 * Description:       Private connector for the Studio Quatro maintenance dashboard. Exposes the site's technical status (WordPress, PHP, plugins, themes, updates, Site Health), email delivery, administrators and an activity log through a key-protected endpoint. It never changes your plugins, themes or content.
 * Version:           1.4.0
 * Requires at least: 5.6
 * Requires PHP:      7.4
 * Author:            Studio Quatro
 * Author URI:        https://studioquatro.com.au
 * License:           GPL-2.0-or-later
 * Text Domain:       sq-site-monitor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/includes/class-sqm-mail.php';
require_once __DIR__ . '/includes/class-sqm-activity.php';

final class SQ_Site_Monitor {

	const VERSION      = '1.4.0';
	const OPTION_KEY   = 'sqm_key';
	const HEADER       = 'X-SQM-Key';
	const MAX_FAILS    = 10;          // failed attempts allowed per IP...
	const FAIL_WINDOW  = 900;         // ...within this window (seconds).
	const OPT_VERSIONS = 'sqm_versions';     // last known versions (baseline)
	const OPT_LOG      = 'sqm_update_log';   // history of version changes
	const OPT_SINCE    = 'sqm_tracking_since';
	const LOG_DAYS     = 400;
	const LOG_MAX      = 600;
	const OPT_OWNER    = 'sqm_owner';        // user who activated the plugin
	const OPT_HIDDEN   = 'sqm_hidden';       // hide from other administrators
	const AGENCY_EMAIL = '@studioquatro.com.au';

	// Self-updates: new versions are published in this public GitHub repository
	// (read straight from GitHub, with the jsDelivr mirror as a fallback) and signed with this key.
	const GITHUB_REPO  = 'DavidQuatro/sq-site-monitor-updates';
	const UPDATE_URLS  = array(
		'https://raw.githubusercontent.com/' . self::GITHUB_REPO . '/main/update.json',
		'https://cdn.jsdelivr.net/gh/' . self::GITHUB_REPO . '@main/update.json',
	);
	const SIGNING_KEY  = 'pGt1YV+0cGQw1nEimS4I3CT8uH7UXuVeMBUsYqPHBHM='; // Ed25519 public key

	public static function init() {
		SQM_Mail::init();
		SQM_Activity::init();
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_action( 'init', array( __CLASS__, 'maybe_fallback_endpoint' ), 1 );
		add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
		add_action( 'admin_post_sqm_regenerate', array( __CLASS__, 'handle_regenerate' ) );
		add_action( 'admin_post_sqm_visibility', array( __CLASS__, 'handle_visibility' ) );
		add_filter( 'all_plugins', array( __CLASS__, 'hide_from_plugin_list' ) );

		// Self-updates, verified with a signature before anything is installed.
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'inject_update' ) );
		add_filter( 'plugins_api', array( __CLASS__, 'plugin_info' ), 10, 3 );
		add_filter( 'upgrader_pre_download', array( __CLASS__, 'verify_download' ), 10, 3 );
		add_filter( 'auto_update_plugin', array( __CLASS__, 'force_auto_update' ), 10, 2 );
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( __CLASS__, 'action_links' ) );

		// Record version changes however they happen (wp-admin, auto-updates, WP-CLI, FTP).
		add_action( 'upgrader_process_complete', array( __CLASS__, 'record_versions' ), 99, 0 );
		add_action( 'automatic_updates_complete', array( __CLASS__, 'record_versions' ), 99, 0 );
		add_action( 'admin_init', array( __CLASS__, 'maybe_record_versions' ) );
	}

	/* ------------------------------------------------------------------ *
	 * Activation / key
	 * ------------------------------------------------------------------ */

	public static function activate() {
		if ( ! get_option( self::OPTION_KEY ) ) {
			update_option( self::OPTION_KEY, self::new_key(), false );
		}
		if ( ! get_option( self::OPT_OWNER ) && get_current_user_id() ) {
			update_option( self::OPT_OWNER, get_current_user_id(), false );
		}
		if ( false === get_option( self::OPT_HIDDEN, false ) ) {
			update_option( self::OPT_HIDDEN, 1, false );
		}
		SQM_Activity::install();
		self::record_versions();
	}

	public static function uninstall() {
		SQM_Mail::uninstall();
		SQM_Activity::uninstall();
		delete_option( self::OPTION_KEY );
		delete_option( self::OPT_VERSIONS );
		delete_option( self::OPT_LOG );
		delete_option( self::OPT_SINCE );
		delete_option( self::OPT_OWNER );
		delete_option( self::OPT_HIDDEN );
	}

	/* ------------------------------------------------------------------ *
	 * Self-updates
	 * ------------------------------------------------------------------ */

	private static function update_urls() {
		return defined( 'SQM_UPDATE_URL' ) ? array( SQM_UPDATE_URL ) : self::UPDATE_URLS;
	}

	/**
	 * Reads update.json (cached for 6 hours). Returns null when it is missing or malformed.
	 */
	private static function remote_info( $force = false ) {
		$cached = get_site_transient( 'sqm_update_info' );
		if ( ! $force && is_array( $cached ) ) {
			return empty( $cached['version'] ) ? null : $cached;
		}
		$info = null;
		foreach ( self::update_urls() as $url ) {
			$res = wp_remote_get( $url, array( 'timeout' => 10 ) );
			if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
				continue;
			}
			$data = json_decode( wp_remote_retrieve_body( $res ), true );
			// A bare file name means "next to update.json", so each location is self-contained.
			if ( is_array( $data ) && ! empty( $data['package'] ) && preg_match( '/^[A-Za-z0-9._-]+\.zip$/', $data['package'] ) ) {
				$data['package'] = trailingslashit( dirname( $url ) ) . $data['package'];
			}
			if ( is_array( $data ) && ! empty( $data['version'] ) && ! empty( $data['package'] ) && ! empty( $data['sha256'] ) && ! empty( $data['signature'] )
				&& 0 === strpos( $data['package'], 'https://' ) ) {
				$info = $data;
				break;
			}
		}
		set_site_transient( 'sqm_update_info', $info ? $info : array(), 6 * HOUR_IN_SECONDS );
		return $info;
	}

	public static function inject_update( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}
		$file = plugin_basename( __FILE__ );
		$info = self::remote_info();
		$item = (object) array(
			'id'          => 'sq-site-monitor',
			'slug'        => 'sq-site-monitor',
			'plugin'      => $file,
			'new_version' => $info ? $info['version'] : self::VERSION,
			'url'         => 'https://studioquatro.com.au',
			'package'     => $info ? $info['package'] : '',
		);
		if ( $info && version_compare( $info['version'], self::VERSION, '>' ) ) {
			if ( ! empty( $info['requires_php'] ) ) {
				$item->requires_php = $info['requires_php'];
			}
			$transient->response[ $file ] = $item;
			unset( $transient->no_update[ $file ] );
		} else {
			$transient->no_update[ $file ] = $item;
			unset( $transient->response[ $file ] );
		}
		return $transient;
	}

	public static function plugin_info( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || 'sq-site-monitor' !== $args->slug ) {
			return $result;
		}
		$info = self::remote_info();
		return (object) array(
			'name'          => 'SQ Site Monitor',
			'slug'          => 'sq-site-monitor',
			'version'       => $info ? $info['version'] : self::VERSION,
			'author'        => 'Studio Quatro',
			'homepage'      => 'https://studioquatro.com.au',
			'download_link' => $info ? $info['package'] : '',
			'sections'      => array(
				'description' => 'Private connector for the Studio Quatro maintenance dashboard.',
				'changelog'   => $info && ! empty( $info['changelog'] ) ? esc_html( $info['changelog'] ) : '',
			),
		);
	}

	/**
	 * Downloads our own package and refuses to install it unless the signature matches.
	 */
	public static function verify_download( $reply, $package, $upgrader ) {
		$info = self::remote_info();
		if ( false !== $reply || ! $info || $package !== $info['package'] ) {
			return $reply;
		}
		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$tmp = download_url( $package, 120 );
		if ( is_wp_error( $tmp ) ) {
			return $tmp;
		}
		$hash    = hash_file( 'sha256', $tmp );
		$message = 'sq-site-monitor:' . $info['version'] . ':' . $hash;
		$ok      = false;
		if ( hash_equals( strtolower( $info['sha256'] ), $hash ) && function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
			try {
				$ok = sodium_crypto_sign_verify_detached( base64_decode( $info['signature'] ), $message, base64_decode( self::SIGNING_KEY ) );
			} catch ( Exception $e ) {
				$ok = false;
			}
		}
		if ( ! $ok ) {
			wp_delete_file( $tmp );
			delete_site_transient( 'sqm_update_info' );
			return new WP_Error( 'sqm_bad_signature', 'SQ Site Monitor: the update package is not signed by Studio Quatro. It was not installed.' );
		}
		return $tmp;
	}

	public static function force_auto_update( $update, $item ) {
		if ( isset( $item->plugin ) && plugin_basename( __FILE__ ) === $item->plugin ) {
			return true;
		}
		if ( isset( $item->slug ) && 'sq-site-monitor' === $item->slug ) {
			return true;
		}
		return $update;
	}

	/* ------------------------------------------------------------------ *
	 * Visibility: hidden from the client's administrators
	 * ------------------------------------------------------------------ */

	/**
	 * Studio Quatro staff: the user who activated the plugin, or any user with an agency email.
	 */
	private static function is_agency_user() {
		$user = wp_get_current_user();
		if ( ! $user || ! $user->exists() ) {
			return false;
		}
		if ( (int) get_option( self::OPT_OWNER ) === (int) $user->ID ) {
			return true;
		}
		$email = strtolower( (string) $user->user_email );
		return substr( $email, -strlen( self::AGENCY_EMAIL ) ) === self::AGENCY_EMAIL;
	}

	private static function is_hidden_for_current_user() {
		// Only hide once we know who the owner is, so nobody gets locked out after an update.
		return (bool) get_option( self::OPT_HIDDEN, 1 ) && get_option( self::OPT_OWNER ) && ! self::is_agency_user();
	}

	public static function hide_from_plugin_list( $plugins ) {
		if ( self::is_hidden_for_current_user() ) {
			unset( $plugins[ plugin_basename( __FILE__ ) ] );
		}
		return $plugins;
	}

	public static function handle_visibility() {
		$no_owner = ! get_option( self::OPT_OWNER );
		if ( ! current_user_can( 'manage_options' ) || ( ! $no_owner && ! self::is_agency_user() ) ) {
			wp_die( 'You do not have permission to do this.' );
		}
		check_admin_referer( 'sqm_visibility' );
		if ( $no_owner ) {
			// Updated in place (not activated), so nobody owns it yet: whoever saves this becomes the owner.
			update_option( self::OPT_OWNER, get_current_user_id(), false );
		}
		update_option( self::OPT_HIDDEN, empty( $_POST['sqm_hidden'] ) ? 0 : 1, false );
		wp_safe_redirect( admin_url( 'tools.php?page=sq-site-monitor&saved=1' ) );
		exit;
	}

	/* ------------------------------------------------------------------ *
	 * Update history
	 * ------------------------------------------------------------------ */

	public static function maybe_record_versions() {
		if ( get_transient( 'sqm_recorded' ) ) {
			return;
		}
		set_transient( 'sqm_recorded', 1, 10 * MINUTE_IN_SECONDS );
		self::record_versions();
	}

	private static function current_versions() {
		global $wp_version;
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		wp_cache_delete( 'plugins', 'plugins' );
		$map = array( 'core' => array( 'type' => 'core', 'name' => 'WordPress', 'version' => $wp_version ) );
		foreach ( get_plugins() as $file => $data ) {
			$map[ 'plugin:' . $file ] = array( 'type' => 'plugin', 'name' => $data['Name'], 'version' => $data['Version'] );
		}
		foreach ( wp_get_themes() as $slug => $theme ) {
			$map[ 'theme:' . $slug ] = array( 'type' => 'theme', 'name' => $theme->get( 'Name' ), 'version' => $theme->get( 'Version' ) );
		}
		return $map;
	}

	/**
	 * Compares current versions with the last known ones and logs every change.
	 */
	public static function record_versions() {
		$current = self::current_versions();
		$known   = get_option( self::OPT_VERSIONS );
		$now     = gmdate( 'c' );

		if ( ! is_array( $known ) ) {
			// First run: just take a baseline.
			update_option( self::OPT_VERSIONS, $current, false );
			update_option( self::OPT_SINCE, $now, false );
			return;
		}

		$log     = get_option( self::OPT_LOG, array() );
		$log     = is_array( $log ) ? $log : array();
		$changed = false;

		foreach ( $current as $key => $item ) {
			$before = isset( $known[ $key ]['version'] ) ? (string) $known[ $key ]['version'] : null;
			$after  = (string) $item['version'];
			if ( $before === $after ) {
				continue;
			}
			$changed = true;
			$log[]   = array(
				'type' => $item['type'],
				'key'  => $key,
				'name' => $item['name'],
				'from' => $before,
				'to'   => $after,
				'time' => $now,
			);
		}

		if ( ! $changed && count( $known ) === count( $current ) ) {
			return;
		}

		$cutoff = time() - self::LOG_DAYS * DAY_IN_SECONDS;
		$log    = array_values( array_filter( $log, function ( $e ) use ( $cutoff ) {
			return isset( $e['time'] ) && strtotime( $e['time'] ) >= $cutoff;
		} ) );
		if ( count( $log ) > self::LOG_MAX ) {
			$log = array_slice( $log, -self::LOG_MAX );
		}

		update_option( self::OPT_LOG, $log, false );
		update_option( self::OPT_VERSIONS, $current, false );
	}

	private static function new_key() {
		return 'sqm_' . wp_generate_password( 40, false, false );
	}

	private static function client_ip() {
		return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
	}

	private static function fail_key() {
		return 'sqm_fail_' . md5( self::client_ip() );
	}

	/**
	 * Checks the key sent in the header. Locks out the IP after too many failed attempts.
	 *
	 * @return true|WP_Error
	 */
	private static function check_key( $provided ) {
		$fails = (int) get_transient( self::fail_key() );
		if ( $fails >= self::MAX_FAILS ) {
			return new WP_Error( 'sqm_locked', 'Too many attempts. Try again later.', array( 'status' => 429 ) );
		}

		$stored = (string) get_option( self::OPTION_KEY );
		if ( '' === $stored || ! is_string( $provided ) || '' === $provided || ! hash_equals( $stored, $provided ) ) {
			set_transient( self::fail_key(), $fails + 1, self::FAIL_WINDOW );
			return new WP_Error( 'sqm_forbidden', 'Invalid key.', array( 'status' => 403 ) );
		}

		return true;
	}

	/* ------------------------------------------------------------------ *
	 * Endpoints
	 * ------------------------------------------------------------------ */

	public static function register_routes() {
		register_rest_route(
			'sqm/v1',
			'/status',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_status' ),
				'permission_callback' => function ( WP_REST_Request $request ) {
					return self::check_key( $request->get_header( 'x_sqm_key' ) );
				},
				'args'                => array(
					'refresh' => array(
						'type'    => 'boolean',
						'default' => false,
					),
				),
			)
		);
	}

	public static function rest_status( WP_REST_Request $request ) {
		nocache_headers();
		$response = rest_ensure_response( self::collect( (bool) $request->get_param( 'refresh' ) ) );
		$response->header( 'Cache-Control', 'no-store, private' );
		return $response;
	}

	/**
	 * Fallback for sites where a security plugin blocks the REST API:
	 * https://site.com/?sqm_status=1 (same header).
	 */
	public static function maybe_fallback_endpoint() {
		if ( ! isset( $_GET['sqm_status'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}

		$provided = isset( $_SERVER['HTTP_X_SQM_KEY'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_SQM_KEY'] ) ) : '';
		$ok       = self::check_key( $provided );

		nocache_headers();
		header( 'Cache-Control: no-store, private' );

		if ( is_wp_error( $ok ) ) {
			$data = $ok->get_error_data();
			wp_send_json( array( 'code' => $ok->get_error_code(), 'message' => $ok->get_error_message() ), isset( $data['status'] ) ? $data['status'] : 403 );
		}

		$refresh = ! empty( $_GET['refresh'] ); // phpcs:ignore WordPress.Security.NonceVerification
		wp_send_json( self::collect( $refresh ), 200 );
	}

	/* ------------------------------------------------------------------ *
	 * Data collection (read-only)
	 * ------------------------------------------------------------------ */

	private static function collect( $refresh = false ) {
		global $wpdb, $wp_version;

		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/update.php';
		require_once ABSPATH . 'wp-admin/includes/theme.php';

		// Force an update check only when asked and the last check is over an hour old.
		if ( $refresh ) {
			$core_t = get_site_transient( 'update_core' );
			if ( ! $core_t || empty( $core_t->last_checked ) || ( time() - $core_t->last_checked ) > HOUR_IN_SECONDS ) {
				if ( function_exists( 'wp_version_check' ) ) {
					wp_version_check();
				}
				if ( function_exists( 'wp_update_plugins' ) ) {
					wp_update_plugins();
				}
				if ( function_exists( 'wp_update_themes' ) ) {
					wp_update_themes();
				}
			}
		}

		self::record_versions();

		$log = get_option( self::OPT_LOG, array() );

		return array(
			'monitor_version' => self::VERSION,
			'monitor_update_urls' => self::update_urls(),
			'generated_at'    => gmdate( 'c' ),
			'site'            => self::site_info(),
			'wordpress'       => self::core_info( $wp_version ),
			'php'             => self::php_info(),
			'server'          => self::server_info( $wpdb ),
			'plugins'         => self::plugins_info(),
			'themes'          => self::themes_info(),
			'site_health'     => self::site_health_info(),
			'security'        => self::security_info(),
			'mcp'             => self::mcp_info(),
			'email'           => SQM_Mail::info(),
			'users'           => SQM_Activity::users_info(),
			'activity'        => SQM_Activity::recent( 150 ),
			'history'         => array(
				'tracking_since' => get_option( self::OPT_SINCE, null ),
				'changes'        => is_array( $log ) ? array_reverse( $log ) : array(),
			),
		);
	}

	private static function site_info() {
		return array(
			'name'       => get_bloginfo( 'name' ),
			'home_url'   => home_url( '/' ),
			'site_url'   => site_url( '/' ),
			'admin_url'  => admin_url(),
			'multisite'  => is_multisite(),
			'locale'     => get_locale(),
			'timezone'   => wp_timezone_string(),
			'admin_email'=> get_option( 'admin_email' ),
			'search_engines_blocked' => ! (bool) get_option( 'blog_public' ),
			'maintenance_mode'       => file_exists( ABSPATH . '.maintenance' ),
		);
	}

	private static function core_info( $current ) {
		$latest      = $current;
		$update_type = 'none';
		$transient   = get_site_transient( 'update_core' );

		if ( $transient && ! empty( $transient->updates ) && is_array( $transient->updates ) ) {
			foreach ( $transient->updates as $offer ) {
				if ( isset( $offer->response, $offer->current ) && 'upgrade' === $offer->response && version_compare( $offer->current, $latest, '>' ) ) {
					$latest = $offer->current;
				}
			}
		}

		if ( version_compare( $latest, $current, '>' ) ) {
			$cur_parts = explode( '.', preg_replace( '/-.*$/', '', $current ) ); // "6.8-RC1" → "6.8"
			$new_parts = explode( '.', $latest );
			$same_branch = ( $cur_parts[0] === $new_parts[0] ) && ( ( $cur_parts[1] ?? '0' ) === ( $new_parts[1] ?? '0' ) );
			$update_type = $same_branch ? 'minor' : 'major';
		}

		return array(
			'version'          => $current,
			'latest'           => $latest,
			'update_available' => 'none' !== $update_type,
			'update_type'      => $update_type,
			'auto_updates'     => array(
				'core_minor' => ! ( defined( 'WP_AUTO_UPDATE_CORE' ) && false === WP_AUTO_UPDATE_CORE ),
				'core_major' => defined( 'WP_AUTO_UPDATE_CORE' ) && true === WP_AUTO_UPDATE_CORE,
			),
			'last_checked'     => ( $transient && ! empty( $transient->last_checked ) ) ? gmdate( 'c', $transient->last_checked ) : null,
		);
	}

	private static function php_info() {
		return array(
			'version'            => PHP_VERSION,
			'memory_limit'       => ini_get( 'memory_limit' ),
			'max_execution_time' => (int) ini_get( 'max_execution_time' ),
			'upload_max_filesize'=> ini_get( 'upload_max_filesize' ),
			'wp_memory_limit'    => defined( 'WP_MEMORY_LIMIT' ) ? WP_MEMORY_LIMIT : null,
		);
	}

	private static function server_info( $wpdb ) {
		$db_size = null;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$size = $wpdb->get_var( $wpdb->prepare( 'SELECT SUM(data_length + index_length) FROM information_schema.TABLES WHERE table_schema = %s', DB_NAME ) );
		if ( null !== $size ) {
			$db_size = (int) $size;
		}

		$disk_free = null;
		if ( function_exists( 'disk_free_space' ) ) {
			$free = @disk_free_space( ABSPATH ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			if ( false !== $free ) {
				$disk_free = (int) $free;
			}
		}

		return array(
			'software'        => isset( $_SERVER['SERVER_SOFTWARE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) : null,
			'db_server'       => method_exists( $wpdb, 'db_server_info' ) ? $wpdb->db_server_info() : $wpdb->db_version(),
			'db_size_bytes'   => $db_size,
			'disk_free_bytes' => $disk_free,
		);
	}

	private static function plugins_info() {
		$all          = get_plugins();
		$active       = (array) get_option( 'active_plugins', array() );
		$network      = is_multisite() ? array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) : array();
		$updates      = get_site_transient( 'update_plugins' );
		$auto_updates = (array) get_site_option( 'auto_update_plugins', array() );
		$list         = array();

		foreach ( $all as $file => $data ) {
			$update = ( $updates && isset( $updates->response[ $file ] ) ) ? $updates->response[ $file ] : null;
			$list[] = array(
				'file'             => $file,
				'name'             => $data['Name'],
				'version'          => $data['Version'],
				'active'           => in_array( $file, $active, true ) || in_array( $file, $network, true ),
				'update_available' => (bool) $update,
				'new_version'      => $update && isset( $update->new_version ) ? $update->new_version : null,
				'auto_update'      => in_array( $file, $auto_updates, true ),
				'author'           => wp_strip_all_tags( $data['Author'] ),
			);
		}

		usort(
			$list,
			function ( $a, $b ) {
				return strcasecmp( $a['name'], $b['name'] );
			}
		);

		return array(
			'total'         => count( $list ),
			'active'        => count( array_filter( $list, function ( $p ) { return $p['active']; } ) ),
			'updates'       => count( array_filter( $list, function ( $p ) { return $p['update_available']; } ) ),
			'last_checked'  => ( $updates && ! empty( $updates->last_checked ) ) ? gmdate( 'c', $updates->last_checked ) : null,
			'items'         => $list,
		);
	}

	/**
	 * Detects plugins that let an AI assistant work on the site over MCP.
	 */
	private static function mcp_info() {
		$known = array(
			'easy-mcp-ai/easy-mcp-ai.php'     => 'Easy MCP AI',
			'mcp-adapter/mcp-adapter.php'     => 'MCP Adapter',
			'wordpress-mcp/wordpress-mcp.php' => 'WordPress MCP',
		);
		$active  = (array) get_option( 'active_plugins', array() );
		if ( is_multisite() ) {
			$active = array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
		}
		$found = array();
		foreach ( get_plugins() as $file => $data ) {
			$is_known = isset( $known[ $file ] );
			$looks    = (bool) preg_match( '/(^|[^a-z])mcp([^a-z]|$)/i', dirname( $file ) . ' ' . $data['Name'] );
			if ( ! $is_known && ! $looks ) {
				continue;
			}
			$found[] = array(
				'file'    => $file,
				'name'    => $is_known ? $known[ $file ] : wp_strip_all_tags( $data['Name'] ),
				'version' => $data['Version'],
				'active'  => in_array( $file, $active, true ),
			);
		}
		$active_found = array_values( array_filter( $found, function ( $p ) { return $p['active']; } ) );
		return array(
			'detected' => ! empty( $active_found ),
			'plugins'  => $found,
		);
	}

	private static function themes_info() {
		$themes   = wp_get_themes();
		$current  = get_stylesheet();
		$template = get_template();
		$updates  = get_site_transient( 'update_themes' );
		$list     = array();

		foreach ( $themes as $slug => $theme ) {
			$update = ( $updates && isset( $updates->response[ $slug ] ) ) ? $updates->response[ $slug ] : null;
			$list[] = array(
				'slug'             => $slug,
				'name'             => $theme->get( 'Name' ),
				'version'          => $theme->get( 'Version' ),
				'active'           => $slug === $current,
				'parent_of_active' => $slug === $template && $slug !== $current,
				'update_available' => (bool) $update,
				'new_version'      => is_array( $update ) && isset( $update['new_version'] ) ? $update['new_version'] : null,
			);
		}

		return array(
			'total'   => count( $list ),
			'updates' => count( array_filter( $list, function ( $t ) { return $t['update_available']; } ) ),
			'active'  => $current,
			'items'   => $list,
		);
	}

	/**
	 * Stored result of the last Site Health run (WordPress recalculates it weekly
	 * via cron and whenever someone opens Tools → Site Health).
	 */
	private static function site_health_info() {
		$raw = get_transient( 'health-check-site-status-result' );
		if ( ! $raw ) {
			return null;
		}
		$data = json_decode( $raw, true );
		if ( ! is_array( $data ) ) {
			return null;
		}
		return array(
			'good'        => isset( $data['good'] ) ? (int) $data['good'] : 0,
			'recommended' => isset( $data['recommended'] ) ? (int) $data['recommended'] : 0,
			'critical'    => isset( $data['critical'] ) ? (int) $data['critical'] : 0,
		);
	}

	private static function security_info() {
		$admins = count_users();
		return array(
			'https_home'         => 0 === strpos( home_url(), 'https://' ),
			'wp_debug'           => defined( 'WP_DEBUG' ) && WP_DEBUG,
			'wp_debug_display'   => defined( 'WP_DEBUG' ) && WP_DEBUG && ( ! defined( 'WP_DEBUG_DISPLAY' ) || WP_DEBUG_DISPLAY ),
			'file_edit_disabled' => defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT,
			'admin_users'        => isset( $admins['avail_roles']['administrator'] ) ? (int) $admins['avail_roles']['administrator'] : null,
			'users_can_register' => (bool) get_option( 'users_can_register' ),
		);
	}

	/* ------------------------------------------------------------------ *
	 * Settings screen (Tools → SQ Monitor)
	 * ------------------------------------------------------------------ */

	public static function admin_menu() {
		if ( self::is_hidden_for_current_user() ) {
			return;
		}
		add_management_page( 'SQ Site Monitor', 'SQ Monitor', 'manage_options', 'sq-site-monitor', array( __CLASS__, 'render_page' ) );
	}

	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'tools.php?page=sq-site-monitor' ) ) . '">View key</a>' );
		return $links;
	}

	public static function handle_regenerate() {
		if ( ! current_user_can( 'manage_options' ) || self::is_hidden_for_current_user() ) {
			wp_die( 'You do not have permission to do this.' );
		}
		check_admin_referer( 'sqm_regenerate' );
		update_option( self::OPTION_KEY, self::new_key(), false );
		wp_safe_redirect( admin_url( 'tools.php?page=sq-site-monitor&regenerated=1' ) );
		exit;
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) || self::is_hidden_for_current_user() ) {
			return;
		}
		$hidden = (bool) get_option( self::OPT_HIDDEN, 1 );
		if ( ! get_option( self::OPTION_KEY ) ) {
			update_option( self::OPTION_KEY, self::new_key(), false );
		}
		$key      = get_option( self::OPTION_KEY );
		$endpoint = rest_url( 'sqm/v1/status' );
		$domain   = wp_parse_url( home_url(), PHP_URL_HOST );
		?>
		<div class="wrap">
			<h1>SQ Site Monitor</h1>
			<?php if ( isset( $_GET['regenerated'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
				<div class="notice notice-success"><p>New key generated. Update it in the dashboard.</p></div>
			<?php endif; ?>
			<?php if ( isset( $_GET['saved'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
				<div class="notice notice-success"><p>Visibility saved.</p></div>
			<?php endif; ?>
			<p>This plugin lets the maintenance dashboard read this site's technical status, email delivery, administrators and an activity log (logins, content, users, plugins and key settings, kept for 90 days). Email recipients are partly hidden in the log. It never changes your plugins, themes or content.</p>

			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">Domain</th>
					<td><code><?php echo esc_html( $domain ); ?></code></td>
				</tr>
				<tr>
					<th scope="row">Key</th>
					<td>
						<input type="text" readonly class="regular-text code" style="width:28em" value="<?php echo esc_attr( $key ); ?>" onclick="this.select()">
						<p class="description">Copy it into the dashboard's <code>sites.json</code> file, next to the domain.</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Line for sites.json</th>
					<td><code>"<?php echo esc_html( $domain ); ?>": "<?php echo esc_html( $key ); ?>"</code></td>
				</tr>
				<tr>
					<th scope="row">Endpoint</th>
					<td><code><?php echo esc_html( $endpoint ); ?></code></td>
				</tr>
			</table>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('The current key will stop working. Continue?');">
				<input type="hidden" name="action" value="sqm_regenerate">
				<?php wp_nonce_field( 'sqm_regenerate' ); ?>
				<?php submit_button( 'Generate new key', 'secondary' ); ?>
			</form>

			<?php if ( self::is_agency_user() || ! get_option( self::OPT_OWNER ) ) : ?>
			<h2>Visibility</h2>
			<?php if ( ! get_option( self::OPT_OWNER ) ) : ?>
				<p><strong>Not hidden yet.</strong> Click "Save visibility" to hide the plugin from other administrators. You will keep seeing it with this user.</p>
			<?php endif; ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="sqm_visibility">
				<?php wp_nonce_field( 'sqm_visibility' ); ?>
				<label><input type="checkbox" name="sqm_hidden" value="1" <?php checked( $hidden ); ?>> Hide this plugin and this page from other administrators</label>
				<p class="description">You still see it when logged in as the user who activated it or with an email ending in <code><?php echo esc_html( self::AGENCY_EMAIL ); ?></code>.</p>
				<?php submit_button( 'Save visibility', 'secondary' ); ?>
			</form>
			<?php endif; ?>
		</div>
		<?php
	}
}

register_activation_hook( __FILE__, array( 'SQ_Site_Monitor', 'activate' ) );
register_uninstall_hook( __FILE__, array( 'SQ_Site_Monitor', 'uninstall' ) );
SQ_Site_Monitor::init();
