<?php
/**
 * Email health: which SMTP plugin is in use, and whether emails are going out.
 *
 * Records every email WordPress tries to send (sent or failed), and also reads the
 * logs of FluentSMTP and WP Mail SMTP when they are installed. Recipients are masked.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SQM_Mail {

	const OPT_LOG = 'sqm_mail_log';
	const LOG_MAX = 200;

	public static function init() {
		add_action( 'wp_mail_succeeded', array( __CLASS__, 'on_sent' ) );
		add_action( 'wp_mail_failed', array( __CLASS__, 'on_failed' ) );
	}

	public static function uninstall() {
		delete_option( self::OPT_LOG );
	}

	/* ---------------- Recording ---------------- */

	public static function on_sent( $mail ) {
		self::add( 'sent', is_array( $mail ) ? $mail : array(), '' );
	}

	public static function on_failed( $error ) {
		$data = ( $error instanceof WP_Error ) ? $error->get_error_data() : array();
		$msg  = ( $error instanceof WP_Error ) ? $error->get_error_message() : '';
		self::add( 'failed', is_array( $data ) ? $data : array(), $msg );
	}

	private static function add( $status, $mail, $error ) {
		$to = isset( $mail['to'] ) ? $mail['to'] : array();
		if ( ! is_array( $to ) ) {
			$to = explode( ',', (string) $to );
		}
		$log   = get_option( self::OPT_LOG, array() );
		$log   = is_array( $log ) ? $log : array();
		$log[] = array(
			'time'    => gmdate( 'c' ),
			'status'  => $status,
			'to'      => implode( ', ', array_map( array( __CLASS__, 'mask' ), array_slice( array_filter( array_map( 'trim', $to ) ), 0, 3 ) ) ),
			'subject' => self::short( isset( $mail['subject'] ) ? (string) $mail['subject'] : '', 90 ),
			'error'   => self::short( wp_strip_all_tags( (string) $error ), 200 ),
		);
		if ( count( $log ) > self::LOG_MAX ) {
			$log = array_slice( $log, -self::LOG_MAX );
		}
		update_option( self::OPT_LOG, $log, false );
	}

	/** "jane.doe@gmail.com" → "ja***@gmail.com" */
	private static function mask( $address ) {
		if ( preg_match( '/<([^>]+)>/', $address, $m ) ) {
			$address = $m[1];
		}
		$address = trim( $address );
		$at      = strrpos( $address, '@' );
		if ( false === $at ) {
			return '***';
		}
		$local = substr( $address, 0, $at );
		return substr( $local, 0, min( 2, strlen( $local ) ) ) . '***' . substr( $address, $at );
	}

	private static function short( $text, $max ) {
		$text = trim( preg_replace( '/\s+/', ' ', $text ) );
		return function_exists( 'mb_strimwidth' ) ? mb_strimwidth( $text, 0, $max, '…' ) : substr( $text, 0, $max );
	}

	/* ---------------- Reading ---------------- */

	private static function smtp_plugins() {
		$known = array(
			'fluent-smtp/fluent-smtp.php'                          => 'FluentSMTP',
			'wp-mail-smtp/wp_mail_smtp.php'                        => 'WP Mail SMTP',
			'wp-mail-smtp-pro/wp_mail_smtp.php'                    => 'WP Mail SMTP Pro',
			'post-smtp/postman-smtp.php'                           => 'Post SMTP',
			'easy-wp-smtp/easy-wp-smtp.php'                        => 'Easy WP SMTP',
			'smtp-mailer/main.php'                                 => 'SMTP Mailer',
			'gosmtp/gosmtp.php'                                    => 'GoSMTP',
			'mailgun/mailgun.php'                                  => 'Mailgun',
			'sendgrid-email-delivery-simplified/wpsendgrid.php'    => 'SendGrid',
			'wp-ses/wp-ses.php'                                    => 'WP Offload SES',
			'brevo/brevo.php'                                      => 'Brevo',
			'mailin/sendinblue.php'                                => 'Brevo',
			'suremails/suremails.php'                              => 'SureMail',
		);
		$active = (array) get_option( 'active_plugins', array() );
		if ( is_multisite() ) {
			$active = array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
		}
		$found = array();
		foreach ( get_plugins() as $file => $data ) {
			$is_known = isset( $known[ $file ] );
			if ( ! $is_known && ! preg_match( '/smtp/i', $file . ' ' . $data['Name'] ) ) {
				continue;
			}
			$found[] = array(
				'name'    => $is_known ? $known[ $file ] : wp_strip_all_tags( $data['Name'] ),
				'version' => $data['Version'],
				'active'  => in_array( $file, $active, true ),
			);
		}
		return $found;
	}

	private static function table_exists( $table ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return $table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) );
	}

	/** FluentSMTP keeps its own log of every email. */
	private static function fluentsmtp_stats() {
		global $wpdb;
		$table = $wpdb->prefix . 'fsmpt_email_logs';
		if ( ! self::table_exists( $table ) ) {
			return null;
		}
		$since = gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$sent   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = 'sent' AND created_at >= %s", $since ) );
		$failed = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = 'failed' AND created_at >= %s", $since ) );
		$last   = $wpdb->get_row( "SELECT status, subject, created_at FROM {$table} ORDER BY id DESC LIMIT 1", ARRAY_A );
		$lastok = $wpdb->get_var( "SELECT created_at FROM {$table} WHERE status = 'sent' ORDER BY id DESC LIMIT 1" );
		// phpcs:enable
		return array(
			'source'    => 'FluentSMTP',
			'sent_7d'   => $sent,
			'failed_7d' => $failed,
			'last'      => $last ? array( 'status' => $last['status'], 'subject' => self::short( (string) $last['subject'], 90 ), 'time' => self::gmt( $last['created_at'] ) ) : null,
			'last_sent' => $lastok ? self::gmt( $lastok ) : null,
		);
	}

	/** WP Mail SMTP records sending errors as "debug events". */
	private static function wpmailsmtp_stats() {
		global $wpdb;
		$table = $wpdb->prefix . 'wpmailsmtp_debug_events';
		if ( ! self::table_exists( $table ) ) {
			return null;
		}
		$since = gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$errors = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE event_type = 0 AND created_at >= %s", $since ) );
		$last   = $wpdb->get_row( "SELECT content, created_at FROM {$table} WHERE event_type = 0 ORDER BY id DESC LIMIT 1", ARRAY_A );
		// phpcs:enable
		return array(
			'source'     => 'WP Mail SMTP',
			'errors_7d'  => $errors,
			'last_error' => $last ? array( 'message' => self::short( wp_strip_all_tags( (string) $last['content'] ), 200 ), 'time' => self::gmt( $last['created_at'] ) ) : null,
		);
	}

	private static function gmt( $mysql_date ) {
		$t = strtotime( $mysql_date . ' UTC' );
		return $t ? gmdate( 'c', $t ) : null;
	}

	public static function info() {
		$log   = get_option( self::OPT_LOG, array() );
		$log   = is_array( $log ) ? $log : array();
		$since = time() - 7 * DAY_IN_SECONDS;
		$sent  = 0;
		$fail  = 0;
		$last_sent = null;
		$last_fail = null;
		foreach ( $log as $e ) {
			$t = strtotime( $e['time'] );
			if ( 'sent' === $e['status'] ) {
				$last_sent = $e['time'];
				if ( $t >= $since ) {
					$sent++;
				}
			} else {
				$last_fail = $e;
				if ( $t >= $since ) {
					$fail++;
				}
			}
		}
		$plugins = self::smtp_plugins();
		return array(
			'smtp_plugins' => $plugins,
			'smtp_active'  => (bool) array_filter( $plugins, function ( $p ) { return $p['active']; } ),
			'sent_7d'      => $sent,
			'failed_7d'    => $fail,
			'last_sent'    => $last_sent,
			'last_failure' => $last_fail,
			'recent'       => array_reverse( array_slice( $log, -30 ) ),
			'fluentsmtp'   => self::fluentsmtp_stats(),
			'wpmailsmtp'   => self::wpmailsmtp_stats(),
		);
	}
}
