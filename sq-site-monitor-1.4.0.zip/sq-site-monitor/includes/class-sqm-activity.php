<?php
/**
 * Activity log and user security.
 *
 * Keeps 90 days of essential events in its own table: logins (and failed logins,
 * grouped per IP), content published, updated, trashed or deleted, media, users
 * created, deleted or changing role, plugins and themes, and key settings.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SQM_Activity {

	const DB_VERSION   = '1';
	const OPT_DB       = 'sqm_activity_db';
	const KEEP_DAYS    = 90;
	const KEEP_ROWS    = 5000;
	const WATCHED_OPTS = array(
		'siteurl'             => 'Site address (WordPress URL)',
		'home'                => 'Site address (URL)',
		'admin_email'         => 'Administration email',
		'users_can_register'  => 'Anyone can register',
		'default_role'        => 'New user default role',
		'blog_public'         => 'Search engine visibility',
		'permalink_structure' => 'Permalink structure',
		'blogname'            => 'Site title',
	);

	private static $old_user = array();

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'sqm_activity';
	}

	public static function init() {
		add_action( 'plugins_loaded', array( __CLASS__, 'maybe_install' ) );

		// Logins.
		add_action( 'wp_login', array( __CLASS__, 'on_login' ), 10, 2 );
		add_action( 'wp_login_failed', array( __CLASS__, 'on_login_failed' ), 10, 1 );

		// Users.
		add_action( 'user_register', array( __CLASS__, 'on_user_register' ) );
		add_action( 'delete_user', array( __CLASS__, 'on_delete_user' ) );
		add_action( 'set_user_role', array( __CLASS__, 'on_set_role' ), 10, 3 );
		add_filter( 'wp_pre_insert_user_data', array( __CLASS__, 'remember_user' ), 10, 3 );
		add_action( 'profile_update', array( __CLASS__, 'on_profile_update' ), 10, 2 );
		add_action( 'after_password_reset', array( __CLASS__, 'on_password_reset' ) );

		// Content.
		add_action( 'transition_post_status', array( __CLASS__, 'on_post_status' ), 10, 3 );
		add_action( 'post_updated', array( __CLASS__, 'on_post_updated' ), 10, 3 );
		add_action( 'before_delete_post', array( __CLASS__, 'on_post_deleted' ) );
		add_action( 'add_attachment', array( __CLASS__, 'on_media_added' ) );
		add_action( 'delete_attachment', array( __CLASS__, 'on_media_deleted' ) );

		// Plugins, themes, core.
		add_action( 'activated_plugin', array( __CLASS__, 'on_plugin_activated' ) );
		add_action( 'deactivated_plugin', array( __CLASS__, 'on_plugin_deactivated' ) );
		add_action( 'deleted_plugin', array( __CLASS__, 'on_plugin_deleted' ), 10, 2 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'on_upgrade' ), 20, 2 );
		add_action( 'switch_theme', array( __CLASS__, 'on_switch_theme' ), 10, 1 );
		add_action( '_core_updated_successfully', array( __CLASS__, 'on_core_updated' ) );

		// Settings.
		add_action( 'updated_option', array( __CLASS__, 'on_option_updated' ), 10, 3 );

		// Housekeeping.
		add_action( 'sqm_activity_cleanup', array( __CLASS__, 'cleanup' ) );
	}

	/* ---------------- Install / cleanup ---------------- */

	public static function maybe_install() {
		if ( get_option( self::OPT_DB ) === self::DB_VERSION ) {
			return;
		}
		self::install();
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		$table   = self::table();
		dbDelta(
			"CREATE TABLE {$table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				created datetime NOT NULL,
				user_id bigint(20) unsigned NOT NULL DEFAULT 0,
				user_login varchar(60) NOT NULL DEFAULT '',
				ip varchar(45) NOT NULL DEFAULT '',
				action varchar(40) NOT NULL DEFAULT '',
				object_type varchar(40) NOT NULL DEFAULT '',
				object_id bigint(20) unsigned NOT NULL DEFAULT 0,
				title varchar(255) NOT NULL DEFAULT '',
				details text NULL,
				hits int(10) unsigned NOT NULL DEFAULT 1,
				PRIMARY KEY  (id),
				KEY created (created),
				KEY action (action)
			) {$charset};"
		);
		update_option( self::OPT_DB, self::DB_VERSION, false );
		if ( ! wp_next_scheduled( 'sqm_activity_cleanup' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'sqm_activity_cleanup' );
		}
	}

	public static function uninstall() {
		global $wpdb;
		$table = self::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( "DROP TABLE IF EXISTS {$table}" );
		delete_option( self::OPT_DB );
		wp_clear_scheduled_hook( 'sqm_activity_cleanup' );
	}

	public static function cleanup() {
		global $wpdb;
		$table = self::table();
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE created < %s", gmdate( 'Y-m-d H:i:s', time() - self::KEEP_DAYS * DAY_IN_SECONDS ) ) );
		$cut = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} ORDER BY id DESC LIMIT 1 OFFSET %d", self::KEEP_ROWS ) );
		if ( $cut ) {
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE id <= %d", $cut ) );
		}
		// phpcs:enable
	}

	/* ---------------- Writing ---------------- */

	private static function ip() {
		return isset( $_SERVER['REMOTE_ADDR'] ) ? substr( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ), 0, 45 ) : '';
	}

	private static function actor() {
		$user = wp_get_current_user();
		if ( $user && $user->exists() ) {
			return array( (int) $user->ID, $user->user_login );
		}
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			return array( 0, 'WP-CLI' );
		}
		if ( wp_doing_cron() ) {
			return array( 0, 'WordPress (automatic)' );
		}
		return array( 0, '' );
	}

	private static function log( $action, $object_type = '', $object_id = 0, $title = '', $details = '', $actor = null ) {
		global $wpdb;
		if ( get_option( self::OPT_DB ) !== self::DB_VERSION ) {
			return 0;
		}
		list( $uid, $login ) = $actor ? $actor : self::actor();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->insert(
			self::table(),
			array(
				'created'     => gmdate( 'Y-m-d H:i:s' ),
				'user_id'     => $uid,
				'user_login'  => substr( (string) $login, 0, 60 ),
				'ip'          => self::ip(),
				'action'      => $action,
				'object_type' => $object_type,
				'object_id'   => (int) $object_id,
				'title'       => function_exists( 'mb_substr' ) ? mb_substr( wp_strip_all_tags( (string) $title ), 0, 250 ) : substr( wp_strip_all_tags( (string) $title ), 0, 250 ),
				'details'     => is_array( $details ) ? wp_json_encode( $details ) : (string) $details,
			),
			array( '%s', '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s' )
		);
		return (int) $wpdb->insert_id;
	}

	/* ---------------- Logins ---------------- */

	public static function on_login( $login, $user ) {
		self::log( 'login', 'user', $user->ID, $login, '', array( (int) $user->ID, $login ) );
	}

	/**
	 * Failed logins are grouped: one row per IP and username every 10 minutes, with a hit counter,
	 * so a brute-force attack cannot flood the database.
	 */
	public static function on_login_failed( $username ) {
		global $wpdb;
		$username = substr( sanitize_user( (string) $username ), 0, 60 );
		$key      = 'sqm_lf_' . md5( self::ip() . '|' . $username );
		$row      = (int) get_transient( $key );
		if ( $row ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->query( $wpdb->prepare( 'UPDATE ' . self::table() . ' SET hits = hits + 1 WHERE id = %d', $row ) );
			return;
		}
		$id = self::log( 'login_failed', 'user', 0, $username, '', array( 0, $username ) );
		if ( $id ) {
			set_transient( $key, $id, 10 * MINUTE_IN_SECONDS );
		}
	}

	/* ---------------- Users ---------------- */

	private static function roles_of( $user_id ) {
		$u = get_userdata( $user_id );
		return $u ? implode( ', ', (array) $u->roles ) : '';
	}

	public static function on_user_register( $user_id ) {
		$u = get_userdata( $user_id );
		self::log( 'user_created', 'user', $user_id, $u ? $u->user_login : '#' . $user_id, array( 'role' => self::roles_of( $user_id ) ) );
	}

	public static function on_delete_user( $user_id ) {
		$u = get_userdata( $user_id );
		self::log( 'user_deleted', 'user', $user_id, $u ? $u->user_login : '#' . $user_id, array( 'role' => self::roles_of( $user_id ) ) );
	}

	public static function on_set_role( $user_id, $role, $old_roles ) {
		if ( empty( $old_roles ) ) {
			return; // brand new user, already logged as user_created
		}
		$u = get_userdata( $user_id );
		self::log( 'role_changed', 'user', $user_id, $u ? $u->user_login : '#' . $user_id, array( 'from' => implode( ', ', (array) $old_roles ), 'to' => $role ) );
	}

	public static function remember_user( $data, $update, $user_id ) {
		if ( $update && $user_id ) {
			$u = get_userdata( $user_id );
			if ( $u ) {
				self::$old_user[ $user_id ] = array( 'email' => $u->user_email, 'pass' => $u->user_pass );
			}
		}
		return $data;
	}

	public static function on_profile_update( $user_id, $old ) {
		$u = get_userdata( $user_id );
		if ( ! $u ) {
			return;
		}
		$before  = isset( self::$old_user[ $user_id ] ) ? self::$old_user[ $user_id ] : array( 'email' => $old->user_email, 'pass' => $old->user_pass );
		$changes = array();
		if ( $before['email'] !== $u->user_email ) {
			$changes[] = 'email';
		}
		if ( $before['pass'] !== $u->user_pass ) {
			$changes[] = 'password';
		}
		if ( $changes ) {
			self::log( 'user_updated', 'user', $user_id, $u->user_login, array( 'changed' => implode( ', ', $changes ) ) );
		}
	}

	public static function on_password_reset( $user ) {
		self::log( 'password_reset', 'user', $user->ID, $user->user_login, '', array( (int) $user->ID, $user->user_login ) );
	}

	/* ---------------- Content ---------------- */

	private static function tracked_post( $post ) {
		if ( ! $post || wp_is_post_revision( $post ) || wp_is_post_autosave( $post ) ) {
			return false;
		}
		if ( in_array( $post->post_type, array( 'revision', 'nav_menu_item', 'customize_changeset', 'oembed_cache', 'user_request', 'wp_global_styles', 'attachment' ), true ) ) {
			return false;
		}
		$type = get_post_type_object( $post->post_type );
		return $type && ( $type->public || in_array( $post->post_type, array( 'wp_template', 'wp_template_part', 'wp_block', 'elementor_library' ), true ) );
	}

	private static function type_label( $post ) {
		$type = get_post_type_object( $post->post_type );
		return $type ? $type->labels->singular_name : $post->post_type;
	}

	public static function on_post_status( $new, $old, $post ) {
		if ( ! self::tracked_post( $post ) || $new === $old ) {
			return;
		}
		$map = array(
			'publish' => 'published',
			'trash'   => 'trashed',
			'future'  => 'scheduled',
		);
		if ( 'trash' === $old && 'trash' !== $new ) {
			$action = 'restored';
		} elseif ( isset( $map[ $new ] ) ) {
			$action = $map[ $new ];
		} elseif ( 'publish' === $old ) {
			$action = 'unpublished';
		} else {
			return; // drafts and auto-drafts are noise
		}
		self::log( 'post_' . $action, $post->post_type, $post->ID, $post->post_title, array( 'type' => self::type_label( $post ) ) );
	}

	public static function on_post_updated( $post_id, $after, $before ) {
		if ( ! self::tracked_post( $after ) || 'publish' !== $after->post_status || 'publish' !== $before->post_status ) {
			return;
		}
		// Only log real changes, and at most once every 10 minutes per user and post (Gutenberg saves often).
		if ( $after->post_content === $before->post_content && $after->post_title === $before->post_title && $after->post_excerpt === $before->post_excerpt ) {
			return;
		}
		$key = 'sqm_pu_' . get_current_user_id() . '_' . $post_id;
		if ( get_transient( $key ) ) {
			return;
		}
		set_transient( $key, 1, 10 * MINUTE_IN_SECONDS );
		self::log( 'post_updated', $after->post_type, $post_id, $after->post_title, array( 'type' => self::type_label( $after ) ) );
	}

	public static function on_post_deleted( $post_id ) {
		$post = get_post( $post_id );
		if ( ! self::tracked_post( $post ) ) {
			return;
		}
		self::log( 'post_deleted', $post->post_type, $post_id, $post->post_title, array( 'type' => self::type_label( $post ) ) );
	}

	public static function on_media_added( $post_id ) {
		self::log( 'media_uploaded', 'attachment', $post_id, get_the_title( $post_id ) );
	}

	public static function on_media_deleted( $post_id ) {
		self::log( 'media_deleted', 'attachment', $post_id, get_the_title( $post_id ) );
	}

	/* ---------------- Plugins, themes, core ---------------- */

	private static function plugin_name( $file ) {
		$path = WP_PLUGIN_DIR . '/' . $file;
		if ( file_exists( $path ) ) {
			if ( ! function_exists( 'get_plugin_data' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}
			$data = get_plugin_data( $path, false, false );
			if ( ! empty( $data['Name'] ) ) {
				return $data['Name'];
			}
		}
		return $file;
	}

	public static function on_plugin_activated( $file ) {
		self::log( 'plugin_activated', 'plugin', 0, self::plugin_name( $file ), array( 'file' => $file ) );
	}

	public static function on_plugin_deactivated( $file ) {
		self::log( 'plugin_deactivated', 'plugin', 0, self::plugin_name( $file ), array( 'file' => $file ) );
	}

	public static function on_plugin_deleted( $file, $deleted ) {
		if ( $deleted ) {
			self::log( 'plugin_deleted', 'plugin', 0, $file, array( 'file' => $file ) );
		}
	}

	public static function on_upgrade( $upgrader, $extra ) {
		if ( empty( $extra['type'] ) || empty( $extra['action'] ) ) {
			return;
		}
		$verb = 'install' === $extra['action'] ? 'installed' : 'updated';
		if ( 'plugin' === $extra['type'] ) {
			$files = ! empty( $extra['plugins'] ) ? (array) $extra['plugins'] : ( ! empty( $extra['plugin'] ) ? array( $extra['plugin'] ) : array() );
			if ( 'install' === $extra['action'] && empty( $files ) && isset( $upgrader->new_plugin_data['Name'] ) ) {
				self::log( 'plugin_installed', 'plugin', 0, $upgrader->new_plugin_data['Name'], array( 'version' => $upgrader->new_plugin_data['Version'] ) );
				return;
			}
			foreach ( $files as $file ) {
				$data = file_exists( WP_PLUGIN_DIR . '/' . $file ) ? get_plugin_data( WP_PLUGIN_DIR . '/' . $file, false, false ) : array();
				self::log( 'plugin_' . $verb, 'plugin', 0, ! empty( $data['Name'] ) ? $data['Name'] : $file, array( 'version' => isset( $data['Version'] ) ? $data['Version'] : '' ) );
			}
		} elseif ( 'theme' === $extra['type'] ) {
			$slugs = ! empty( $extra['themes'] ) ? (array) $extra['themes'] : ( ! empty( $extra['theme'] ) ? array( $extra['theme'] ) : array() );
			foreach ( $slugs as $slug ) {
				$theme = wp_get_theme( $slug );
				self::log( 'theme_' . $verb, 'theme', 0, $theme->exists() ? $theme->get( 'Name' ) : $slug, array( 'version' => $theme->exists() ? $theme->get( 'Version' ) : '' ) );
			}
		}
	}

	public static function on_switch_theme( $name ) {
		self::log( 'theme_switched', 'theme', 0, $name );
	}

	public static function on_core_updated( $version ) {
		self::log( 'core_updated', 'core', 0, 'WordPress ' . $version, array( 'version' => $version ) );
	}

	/* ---------------- Settings ---------------- */

	public static function on_option_updated( $option, $old, $new ) {
		if ( ! isset( self::WATCHED_OPTS[ $option ] ) || $old === $new ) {
			return;
		}
		$fmt = function ( $v ) {
			return is_scalar( $v ) ? substr( (string) $v, 0, 120 ) : '(changed)';
		};
		self::log( 'setting_changed', 'option', 0, self::WATCHED_OPTS[ $option ], array( 'option' => $option, 'from' => $fmt( $old ), 'to' => $fmt( $new ) ) );
	}

	/* ---------------- Reading ---------------- */

	public static function recent( $limit = 150 ) {
		global $wpdb;
		if ( get_option( self::OPT_DB ) !== self::DB_VERSION ) {
			return array();
		}
		$table = self::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A );
		$out  = array();
		foreach ( (array) $rows as $r ) {
			$details = json_decode( (string) $r['details'], true );
			$out[]   = array(
				'time'    => gmdate( 'c', strtotime( $r['created'] . ' UTC' ) ),
				'user'    => $r['user_login'],
				'ip'      => $r['ip'],
				'action'  => $r['action'],
				'type'    => $r['object_type'],
				'id'      => (int) $r['object_id'],
				'title'   => $r['title'],
				'details' => is_array( $details ) ? $details : null,
				'hits'    => (int) $r['hits'],
			);
		}
		return $out;
	}

	private static function last_login( $user_id ) {
		global $wpdb;
		$table = self::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$t = $wpdb->get_var( $wpdb->prepare( "SELECT created FROM {$table} WHERE action = 'login' AND user_id = %d ORDER BY id DESC LIMIT 1", $user_id ) );
		return $t ? gmdate( 'c', strtotime( $t . ' UTC' ) ) : null;
	}

	public static function users_info() {
		global $wpdb;
		$ready  = get_option( self::OPT_DB ) === self::DB_VERSION;
		$admins = array();
		$ids    = get_users( array( 'role' => 'administrator', 'fields' => 'ID', 'number' => 50 ) );
		if ( is_multisite() ) {
			foreach ( get_super_admins() as $login ) {
				$u = get_user_by( 'login', $login );
				if ( $u ) {
					$ids[] = $u->ID;
				}
			}
		}
		foreach ( array_unique( array_map( 'intval', $ids ) ) as $id ) {
			$u = get_userdata( $id );
			if ( ! $u ) {
				continue;
			}
			$admins[] = array(
				'login'      => $u->user_login,
				'email'      => $u->user_email,
				'registered' => gmdate( 'c', strtotime( $u->user_registered . ' UTC' ) ),
				'last_login' => $ready ? self::last_login( $id ) : null,
			);
		}

		$failed_24h = 0;
		$failed_7d  = 0;
		$top_ips    = array();
		if ( $ready ) {
			$table = self::table();
			// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$failed_24h = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(hits),0) FROM {$table} WHERE action = 'login_failed' AND created >= %s", gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS ) ) );
			$failed_7d  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(hits),0) FROM {$table} WHERE action = 'login_failed' AND created >= %s", gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS ) ) );
			$top_ips    = $wpdb->get_results( $wpdb->prepare( "SELECT ip, SUM(hits) AS attempts FROM {$table} WHERE action = 'login_failed' AND created >= %s GROUP BY ip ORDER BY attempts DESC LIMIT 5", gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS ) ), ARRAY_A );
			// phpcs:enable
		}

		$counts = count_users();
		return array(
			'tracking'      => $ready,
			'total'         => isset( $counts['total_users'] ) ? (int) $counts['total_users'] : null,
			'roles'         => isset( $counts['avail_roles'] ) ? array_filter( $counts['avail_roles'] ) : array(),
			'admins'        => $admins,
			'failed_24h'    => $failed_24h,
			'failed_7d'     => $failed_7d,
			'failed_top_ips' => array_map( function ( $r ) { return array( 'ip' => $r['ip'], 'attempts' => (int) $r['attempts'] ); }, (array) $top_ips ),
		);
	}
}
